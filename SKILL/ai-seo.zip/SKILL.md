---
name: ai-seo
description: Expert in AI search optimization (GEO/AEO). Use when optimizing content for citations in Google AI Overviews, ChatGPT, Perplexity, Gemini, Claude, and Copilot, checking robots.txt AI crawler access, auditing AI visibility, or implementing agent-ready files.
---
# AI Search Optimization (AI SEO / GEO)

Guide content discoverability, extractability, and citable authority across modern AI search engines and autonomous AI agents.

## When to Use

- User asks how to get cited or recommended by ChatGPT, Perplexity, Google AI Overviews, Gemini, Claude, or Copilot.
- Evaluating robots.txt crawler access for AI user-agents (GPTBot, PerplexityBot, ClaudeBot, Google-Extended).
- Auditing content extractability, structure, and E-E-A-T signals for Generative Engine Optimization (GEO).
- Preparing site architecture for AI agents via machine-readable files (`/pricing.md`, `/llms.txt`, schema markup).
- Formulating content strategies (handling listicles, comparisons, benchmarks, and original research).

*Note: For traditional technical crawling, indexing drops, or general site health audits, refer to standard SEO audit practices.*

## Core Principles

- **Traditional SEO ranks; AI SEO cites:** High rank helps Google AI Overviews, but modern LLMs cite authoritative, extractable pages across the web regardless of page-1 ranking.
- **Write for humans, structure for clarity:** Do not create duplicate synthetic content "for AI" (risks scaled content abuse). Use standard semantic HTML, clear headings, and direct answer blocks.
- **Citation vs. Recommendation:** Earning a citation means being retrieved as reference material; winning a buyer recommendation requires strong off-site consensus (third-party reviews, Reddit, PR, analyst mentions).

## The Three Pillars Framework

### 1. Structure (Extractability)
- **Answer-First:** Lead every section with a concise, direct answer (40-60 words) before diving into details.
- **Standalone Passages:** Ensure key claims, definitions, and conclusions can stand alone when pulled without surrounding context.
- **Format Match:**
  - "What is" -> Concise definition block in paragraph 1.
  - "How to" -> Numbered step-by-step processes.
  - "X vs Y" -> Markdown comparison tables with distinct criteria.
  - Common queries -> Structured FAQ blocks.
- **Semantic HTML:** Keep essential content in the initial server-rendered HTML (not blocked behind client-side JavaScript rendering).

### 2. Authority (Citable Weight)
Ground claims with high-verifiability signals (Princeton GEO research: citations increase visibility by up to +40%, statistics by +37%):
- **Specific Data:** Include exact numbers, dates, and link to primary research rather than summaries.
- **Named Attribution:** Attribute quotes, methodologies, and findings to clear author identities with credentials.
- **Freshness:** Prominently display "Last updated: [Date]" and regularly refresh time-sensitive claims.
- **Avoid Keyword Stuffing:** Packing repetitive keywords reduces AI visibility by ~10%.

### 3. Presence (Off-Site Footprint & Agent Readiness)
- **Third-Party Coverage:** Build authentic presence on review platforms (G2, Capterra), relevant community forums, and reputable industry publications.
- **Machine-Readable Files:**
  - `/llms.txt`: High-level overview of purpose, audience, and essential documentation links.
  - `/pricing.md`: Plain markdown pricing tiers, limits, and inclusions so autonomous buying agents don't filter out opaque pricing.
- **Structured Data:** Implement JSON-LD schema (Article, HowTo, FAQPage, Product, Organization) to assist parser comprehension.

## AI Bot Access Verification (robots.txt)

Verify that AI crawlers are not inadvertently blocked if citation is desired:
- `GPTBot` & `ChatGPT-User` (OpenAI / ChatGPT)
- `PerplexityBot` (Perplexity)
- `ClaudeBot` & `anthropic-ai` (Anthropic / Claude)
- `Google-Extended` (Google Gemini & AI training)
- `Bingbot` (Microsoft Copilot)

*Trade-off:* Blocking AI bots prevents training on proprietary data, but completely eliminates visibility and direct citations in AI-assisted answers. If protecting content from bulk scraping, disallow training crawlers (e.g., `CCBot`) while whitelisting citation and search crawlers.

## Multi-Platform Considerations

- **Google AI Overviews / AI Mode:** Correlates heavily with core Search ranking and E-E-A-T. Handles query fan-out (spawning related sub-queries), requiring broad topical coverage across clusters rather than hyper-focused thin pages.
- **ChatGPT & Perplexity:** Actively scan broad web sources, documentation, and structured summaries. Reward primary sources, clear tables, and verified data over generic affiliate listicles.
- **Measurement Rigor:** AI outputs are non-deterministic. Never evaluate visibility on a single query test; run queries 3-5 times across target platforms and evaluate mention rates over time.
